def msg_send(text_msg, userid):
