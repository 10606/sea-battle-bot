import sys, time, math,random
import vk
from client_cerver_sock import *
for i in range(10):
    for j in range(10):
        temp = get_answer(i + 1, j + 1);
        print(temp)
